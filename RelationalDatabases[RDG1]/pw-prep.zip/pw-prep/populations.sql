insert into public.populations (population_code, population_year, population_period)
values  ('DSA', 2021, 'SPRING'),
        ('SE', 2021, 'SPRING'),
        ('CS', 2021, 'SPRING'),
        ('ISM', 2021, 'SPRING'),
        ('AIs', 2021, 'SPRING'),
        ('DSA', 2020, 'SPRING'),
        ('SE', 2020, 'SPRING'),
        ('CS', 2020, 'SPRING'),
        ('ISM', 2020, 'SPRING'),
        ('AIs', 2020, 'SPRING');